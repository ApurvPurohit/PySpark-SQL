HOW TO RUN
* Install Python3.6
* Run "pip install -r requirements.txt" command to install dependencies.
* Run "python app.py" to run the WebApp.
* Visit http://localhost:5000

To migrate multiple tables, follow the below steps:
1. Edit the text-file 'table_file.txt' present in the WebApp directory. Add records in the
format "DBNAME*TABLENAME". Keep only one record in a line.
2. Take care of case sensitivity. A sample table file is provided in the WebApp directory 
for reference.
3. Once added records, save the file, and click on the 'MIGRATE TABLE - FILE' button.