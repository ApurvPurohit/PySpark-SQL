
Dev = {
    "db_server": "wn000022700",
    "user": "powerfacets",
    "passwd": "P#(8t?aSd:9r#`",
	"driver": "SQL Server",
    "port": "1433"
}

Oracle = {
    "db_server": "es20-scan01",
    "port": "1521",
    "user": "POWERFACETS_MIGRATION",
    "passwd": "t;.<4vQj",
	"service_name": "cmc1st01svc.uhc.com"
}

# Stage = {
#     "db_server": "dbsws0517.dmzmgmt.uhc.com",
#     "user": "appPhysicalHealth",
#     "passwd": "6CzZJL7Ft95W",
# 	"driver": "SQL Server"
# }
#
# Prod = {
#     "db_server": "localhost",
#     "user": "",
#     "passwd": "my secret password",
# 	"driver": "SQL Server"
# }