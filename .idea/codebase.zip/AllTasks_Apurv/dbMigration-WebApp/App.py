import time
import logging
import findspark
findspark.init()
from pyspark.sql.types import *
import numpy as np
from pyspark.sql import session
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_timestamp, lit, to_date, date_format, col, udf
from pyspark.sql import SQLContext
from flask import Flask, render_template, request, redirect
import pyodbc
import os
import urllib
import sqlalchemy
import pandas as pd
import Config as config
from datetime import datetime
import cx_Oracle
import pandas as pd
from sqlalchemy import create_engine
spark = SparkSession.builder.appName("ETL") \
        .config("spark.driver.extraClassPath", "sqljdbc42.jar") \
        .getOrCreate()
spark.conf.set("spark.sql.debug.maxToStringFields", 1000)
# Create and configure logger
logging.basicConfig(filename="Migration.log",
                    format='%(asctime)s %(message)s',
                    filemode='w')
# Creating an object
logger = logging.getLogger()

# Setting the threshold of logger to DEBUG
logger.setLevel(logging.INFO)
# Set Oralce Connection
cx_Oracle.init_oracle_client(
    lib_dir=r"C:\Users\apurohi9\Downloads\instantclient-basic-windows.x64-19.11.0.0.0dbru\instantclient_19_11")
dsn_tns = cx_Oracle.makedsn(config.Oracle['db_server'], config.Oracle['port'], service_name=config.Oracle['service_name'])
conn = cx_Oracle.connect(user=config.Oracle['user'], password=config.Oracle['passwd'], dsn=dsn_tns)
# Open cursor
cursor = conn.cursor()
logger.info("Connected to Oracle DB!")
def write_into_database(dataframe, database, table_name,  mode):
    dataframe.write \
        .format("jdbc") \
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
        .option("url","jdbc:sqlserver://wn000022700:1433;databaseName="+database) \
        .option("dbtable", table_name) \
        .option("user", config.Dev['user']) \
        .option("password", config.Dev['passwd']) \
        .mode(saveMode=mode) \
        .save()
def multiple_table_migration():
    k = 1
    total = ""
    logger.info("Multiple Table Migration Chosen.\nMigratiion starting:")
    with open("table_file.txt") as f:
        for line in f:
            tup = line.split("*")
            db = tup[0].strip()
            tbl = tup[1].strip()
            print('Migration details received for Table', tbl)
            logger.info('Migration initiate for Table: '+tbl)
            print(db,tbl)
            status, tt = migratedb(db, tbl)
            total += "Table " + tbl + "| " + tt + "\n"
            logger.info('Migration complete for Table {} {}'.format(tbl, tt))
            k += 1
    status = "All tables in the table_file have been successfully migrated!"
    logger.info(status)
    return (status,total)

def migratedb(dbname, tblname):
    print("Migration Begins!")
    sql = "SELECT * FROM "+dbname+"."+tblname
    data = pd.read_sql(sql, conn, chunksize=300000)
    res = 0
    file = open('mig-temp.csv','a')
    tempfile = 'mig-temp.csv'
    for chunk in data:
        chunk.to_csv(tempfile, mode='a')
        res += len(chunk.index)
        print("Chunk to CSV(Records written):", res, end='\r')
    print('\n')
    print('Temp Csv created!')
    isempty = os.path.getsize(tempfile) == 0
    if (isempty):
        status1 = "No data present at source!"
        logger.info(dbname+"."+tblname+"::"+str(status1))
        return (status1, "000")
    df = spark.read \
        .format("csv") \
        .option("header", "true") \
        .option("inferSchema", "true") \
        .load(tempfile)
    TableName = tblname
    DatabaseName = dbname
    df = df.drop('_c0')
    print("Insertion Begins:")
    logger.info("Insertion Begins: "+dbname+"."+tblname)
    start = time.time()
    write_into_database(df, DatabaseName, TableName, 'Append')
    print("Rows Inserted:", df.count())
    logger.info("Rows Inserted: {}".format(df.count()))
    end = time.time()
    hours, rem = divmod(end - start, 3600)
    minutes, seconds = divmod(rem, 60)
    file.close()
    os.remove(tempfile)
    status = "Data successfully pushed to SQL Server!"
    logger.info(status)
    print(status)
    logger.info("Time taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    print('Temp Csv removed!')
    print("Migration Ends :)")
    tt = "\nTime taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds)
    print(tt)
    return (status, tt)


app = Flask(__name__)

@app.route('/')
def index():
  return render_template('index.html')

@app.route('/migrate/', methods=['POST'])
def migrate():
    database_name = request.form['dbname']
    tablename = request.form['tblname']
    print ('Migration Details Received!')
    logger.info('Migration Details Received!')
    if((database_name == '#') and (tablename == '#')):
        status, tt = multiple_table_migration()
    else:
        status, tt = migratedb(database_name,tablename)
    templateData = {
        'status': status,
        'time': tt
    }
    return render_template('result.html', **templateData)

if __name__ == '__main__':
    # migratedb(dbname,tablename) # To migrate a single Table
    # app.run(debug=True)
    multiple_table_migration()  # To migrate multiple Tables as present in table_file.txt

