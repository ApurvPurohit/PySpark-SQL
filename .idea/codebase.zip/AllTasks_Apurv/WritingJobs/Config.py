
Dev = {
    "db_server": "Dbsed4555",
    "user": "AppPhysicalHealth",
    "passwd": "X#rRb8Q%BR:M",
	"driver": "SQL Server",
    "port": "1433"
}

# Test = {
#     "db_server": "",
#     "user": "",
#     "passwd": "my secret password",
# 	"driver": "SQL Server"
# }
#
# Stage = {
#     "db_server": "dbsws0517.dmzmgmt.uhc.com",
#     "user": "appPhysicalHealth",
#     "passwd": "6CzZJL7Ft95W",
# 	"driver": "SQL Server"
# }
#
# Prod = {
#     "db_server": "localhost",
#     "user": "",
#     "passwd": "my secret password",
# 	"driver": "SQL Server"
# }