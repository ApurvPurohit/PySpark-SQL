import logging
import time
import findspark
findspark.init()
from pyspark.sql.types import *
import numpy as np
from pyspark.sql import session
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_timestamp, lit
import pyodbc
import urllib
import sqlalchemy
import pandas as pd
import Config as config
from datetime import datetime
loaddate = str(datetime.now())[:-4]
spark = SparkSession.builder.appName("ETL")\
        .config("spark.driver.extraClassPath","sqljdbc42.jar")\
        .getOrCreate()
spark.conf.set("spark.sql.debug.maxToStringFields", 1000)
# Create and configure logger
logging.basicConfig(filename="Job606_Premera.log",
                    format='%(asctime)s %(message)s',
                    filemode='w')
# Creating an object
logger = logging.getLogger()
# Setting the threshold of logger to DEBUG
logger.setLevel(logging.INFO)
def execute_sql(db, query,record_list):
    try:
        connection = pyodbc.connect('driver={%s};server=%s;database=%s;uid=%s;pwd=%s' % (config.Dev['driver'],
                                                                                         config.Dev['db_server'], db,
                                                                                         config.Dev['user'],
                                                                                         config.Dev['passwd']))
        cursor = connection.cursor()
        print(query)
        if "insert" in query:
            if not record_list :
                cursor.execute(query)
                print("Executed the query")
                logger.info("Executed the query - %s", query)
            else :
                cursor.executemany(query,record_list)
                print("Executed the query")
                logger.info("Executed the query - %s", query)
            connection.commit()
        else:
            cursor.execute(query)
            print("Executed the query")
            logger.info("Executed the query - %s", query)
            return cursor
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)
        logger.info('Exception Occurred:', e.__class__.__name__)


def write_into_database(dataframe, database, table_name,  mode):
    dataframe.write \
        .format("jdbc") \
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
        .option("url","jdbc:sqlserver://Dbsed4555:1433;databaseName=Eligibility") \
        .option("dbtable", table_name) \
        .option("user", config.Dev['user']) \
        .option("password", config.Dev['passwd']) \
        .mode(saveMode=mode) \
        .save()

def writefile():
    empty_list = []
    write_query = """ 
                      SELECT DISTINCT 
                      PLTP.TinNumber, PLI.AcnProvID, PIN.ProvFirstName, PIN.ProvLastName, PIN.ProvMI, PC.ProviderSpecialty, OLI.ClinicName, OLI.LocAddress1, 
                      OLI.LocAddress2, OLI.LocCity, OLI.LocState, OLI.LocZip, PE.provphone, PIN.ProvSex
FROM                  Provider.dbo.T_ProviderContracts AS PC WITH (NOLOCK) INNER JOIN
                      Provider.dbo.T_ProviderLocationPointer AS PLI WITH (NOLOCK) ON PC.AcnProvID = PLI.AcnProvID INNER JOIN
                      Provider.dbo.T_ProviderInformation AS PIN WITH (NOLOCK) ON PLI.ProviderID = PIN.ProviderID INNER JOIN
                      Provider.dbo.T_OfficeLocationInfo AS OLI WITH (NOLOCK) ON PLI.OfficeLocationID = OLI.OfficeLocationID INNER JOIN
                      Provider.dbo.T_ProviderElectronics AS PE WITH (NOLOCK) ON PC.AcnProvID = PE.ACNPROVID INNER JOIN
                      Provider.dbo.T_ProvLocTinPointer AS PLTP WITH (NOLOCK) ON PLI.ProviderID = PLTP.ProviderID AND PLI.OfficeLocationID = PLTP.OfficeLocationID
WHERE     (PC.ProviderSpecialty IN ('DC', 'LAC', 'MT', 'ND', 'D/N')) AND (PC.ClientID = '580') AND (PC.ContTermDate IS NULL OR
                      PC.ContTermDate > GETDATE() + 40) AND (PLI.TermDate IS NULL) AND (PLTP.TermDate IS NULL) AND (PIN.ProviderID NOT IN ('111111', '648027', 
                      '663910', '669243', '693301', '693302', '693304', '701178', '712410', '999998', '999999'))"""
    cursor = execute_sql("Provider", write_query, empty_list)
    result = cursor.fetchall()
    logger.info("Query Results fetched")
    print(type(result))
    f = open("PREMERA-Job606.txt", "a")
    line = ''
    for tup in result:
        line = ''
        for v in tup:
            if(v is None):
                line += '~'
            else:
                line += v
                line += '~'
        line = line[:-1]
        line += '\n'
        f.write(line)
    f.close()
    print("File written!")
    logger.info("File written!")

def main():
    try:
        writefile()
        return 0
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)
        logger.info('Exception Occurred:', e.__class__.__name__)

if __name__ == "__main__":
    main()