import logging
import time
import findspark
findspark.init()
from pyspark.sql.types import *
import numpy as np
from pyspark.sql import session
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_timestamp, lit
import pyodbc
import urllib
import sqlalchemy
import pandas as pd
import Config as config
from datetime import datetime
loaddate = str(datetime.now())[:-4]
spark = SparkSession.builder.appName("ETL")\
        .config("spark.driver.extraClassPath","sqljdbc42.jar")\
        .getOrCreate()
spark.conf.set("spark.sql.debug.maxToStringFields", 1000)
# Create and configure logger
logging.basicConfig(filename="Job207-MTK.log",
                    format='%(asctime)s %(message)s',
                    filemode='w')
# Creating an object
logger = logging.getLogger()

# Setting the threshold of logger to DEBUG
logger.setLevel(logging.INFO)

def execute_sql(db, query,record_list):
    try:
        connection = pyodbc.connect('driver={%s};server=%s;database=%s;uid=%s;pwd=%s' % (config.Dev['driver'],
                                                                                         config.Dev['db_server'], db,
                                                                                         config.Dev['user'],
                                                                                         config.Dev['passwd']))
        cursor = connection.cursor()
        print(query)
        if "insert" in query:
            if not record_list :
                cursor.execute(query)
                print("Executed the query")
                logger.info("Executed the query - %s", query)
            else :
                cursor.executemany(query,record_list)
                print("Executed the query")
                logger.info("Executed the query - %s", query)
            connection.commit()
        else:
            cursor.execute(query)
            print("Executed the query")
            logger.info("Executed the query - %s", query)
            return cursor
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)

def executefast_sql(db, TableName, record_list):
    conn = pyodbc.connect('driver={%s};server=%s;database=%s;uid=%s;pwd=%s' % (config.Dev['driver'],
                                                                                     config.Dev['db_server'], db,
                                                                                     config.Dev['user'],
                                                                                     config.Dev['passwd']))

    insert_query="insert into eligibility.dbo.tblHealthNewEnglandLoad values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    cursor = conn.cursor()
    cursor.executemany(insert_query, record_list)
    cursor.commit()
    print(f'{len(record_list)} rows inserted to the table ',TableName)
    cursor.close()
    conn.close()

def get_loadnum():
    empty_list=[]
    insert_Load = "insert into eligibility..t_eligloads values ('" + loaddate + "','COSMOSMTK_0000.TXT'," \
                                                                                "'MedicaMTKLoad','100')"
    execute_sql("Eligibility", insert_Load, empty_list)
    exec_sp = "exec usp_ClearTable 'MedicaMTKLoad'"
    execute_sql("Eligibility", exec_sp, empty_list)
    selectloadnum = "Select Top 1 LoadNum from T_EligLoads where TableName='MedicaMTKLoad' Order By LoadNum desc"
    cursor = execute_sql("Eligibility", selectloadnum,empty_list)
    return str(cursor.fetchone()[0])

def write_into_database(dataframe, database, table_name,  mode):
    dataframe.write \
        .format("jdbc") \
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
        .option("url","jdbc:sqlserver://Dbsed4555:1433;databaseName=Eligibility") \
        .option("dbtable", table_name) \
        .option("user", config.Dev['user']) \
        .option("password", config.Dev['passwd']) \
        .mode(saveMode=mode) \
        .save()

def readfile():
    df = spark.read.format("Text").option("header", "true").load("COSMOSMTK_0000_20121217.TXT")
    df2 = df.select(
        lit(get_loadnum()).alias('LoadNum'),
        df.value.substr(1, 1).alias('TransType'),
        df.value.substr(2, 3).alias('Site'),
        df.value.substr(5, 5).alias('GroupNum'),
        df.value.substr(10, 9).alias('SubscriberNum'),
        df.value.substr(19, 2).alias('Relationship'),
        df.value.substr(21, 12).alias('FirstName'),
        df.value.substr(33, 1).alias('MI'),
        df.value.substr(34, 18).alias('LastName'),
        df.value.substr(52, 30).alias('Address1'),
        df.value.substr(82, 30).alias('Address2'),
        df.value.substr(112, 15).alias('City'),
        df.value.substr(127, 2).alias('State'),
        df.value.substr(129, 5).alias('ZipCode'),
        df.value.substr(134, 4).alias('ZipCodeExt'),
        df.value.substr(138, 4).alias('CountyCode'),
        df.value.substr(142, 3).alias('HomeAreaCode'),
        df.value.substr(145, 7).alias('HomePhoneNum'),
        df.value.substr(152, 3).alias('WorkAreaCode'),
        df.value.substr(155, 7).alias('WorkPhoneNum'),
        df.value.substr(162, 1).alias('MaritalStatus'),
        to_timestamp(df.value.substr(163, 0), 'yyyy-MM-dd HH:mm:ss').alias('DOB'),
        df.value.substr(163, 1).alias('Sex'),
        df.value.substr(164, 9).alias('SSN'),
        to_timestamp(df.value.substr(173, 0), 'yyyy-MM-dd HH:mm:ss').alias('OriginalEffDate'),
        df.value.substr(173, 12).alias('MedicareNum'),
        df.value.substr(185, 1).alias('HCFAStatus'),
        df.value.substr(186, 16).alias('MedicaidNum'),
        to_timestamp(df.value.substr(202, 0), 'yyyy-MM-dd HH:mm:ss').alias('EffDate'),
        to_timestamp(df.value.substr(202, 0), 'yyyy-MM-dd HH:mm:ss').alias('ExpDate'),
        df.value.substr(202, 1).alias('MedicalCov'),
        df.value.substr(203, 1).alias('DentalCov'),
        df.value.substr(204, 1).alias('VisionCov'),
        df.value.substr(205, 1).alias('AncillaryCov'),
        df.value.substr(206, 7).alias('MedicalProvNum'),
        df.value.substr(213, 7).alias('DentalProvNum'),
        df.value.substr(220, 5).alias('MedicalBenPkg'),
        df.value.substr(225, 5).alias('DentalBenPkg'),
        df.value.substr(230, 5).alias('VisionBenPkg'),
        df.value.substr(235, 2).alias('MedicalClassCode'),
        df.value.substr(237, 1).alias('AdultOrDependent'),
        df.value.substr(238, 10).alias('ClientCode'),
        df.value.substr(248, 12).alias('DeptNum'),
        df.value.substr(260, 30).alias('MedicalProvName'),
        df.value.substr(290, 10).alias('MedicalProvPhone'),
        df.value.substr(300, 30).alias('DentalProvName'),
        df.value.substr(330, 10).alias('DentalProvPhone'),
        df.value.substr(340, 18).alias('EmployeeAltID'),
        df.value.substr(358, 5).alias('RxBenPkgNum'),
        df.value.substr(363, 2).alias('EmployeeClassCode'),
        df.value.substr(365, 1).alias('MemberCOB'),
        df.value.substr(366, 3).alias('SubscriberLang'),
        df.value.substr(369, 9).alias('CESAltID'),
        df.value.substr(378, 41).alias('MemberID')
    )
    logger.info("Created the dataframe from the given data file")
    print(type(df2))
    TableName = 'dbo.MedicaMTKLoad'
    start = time.time()
    logger.info("Started Writing to database")
    logger.info("Inserting into table %s", TableName)
    write_into_database(df2, 'Eligibility', TableName, 'Append')
    print("Rows Inserted:", df2.count())
    end = time.time()
    hours, rem = divmod(end - start, 3600)
    minutes, seconds = divmod(rem, 60)
    logger.info("Written to database Successfully")
    logger.info("Rows Inserted: {}".format(df2.count()))
    logger.info("Time taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    print("\nTime taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))

def main():
    try:
        readfile()
        return 0
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)

if __name__ == "__main__":
    main()

# from pyspark import SparkConf, SparkContext
# from pyspark.sql import SparkSession
#
# # Create spark configuration object
# conf = SparkConf()
# conf.setMaster("local").setAppName("My app")
#
# # Create spark context and sparksession
# sc = SparkContext.getOrCreate(conf=conf)
# spark = SparkSession(sc)
# # set variable to be used to connect the database
# database = "Commlog"
# selectquery = "SELECT DISTINCT CLH.[LogNum],CONVERT(VARCHAR(10),[LogDate],110) AS LogDate,CONVERT(VARCHAR, [LogTime], 108) AS LogTime ,CLH.[USERID],CLH.[PROVIDERID] ,CLH.[OFFICEID],CLH.[LOGType],LT.[TypeDesc] FROM [CommLog].[dbo].[T_CommLogHeader] (NOLOCK) AS CLH INNER JOIN Commlog.dbo.T_LogType (NOLOCK) AS LT ON LT.TypeCode = CLH.LOGType INNER JOIN commlog.dbo.T_Source (NOLOCK) AS S ON S.SourceCode = CLH.LogSource INNER JOIN CommLog.dbo.Inquirydata (NOLOCK) AS ID ON ID.InquiryCode = CLH.InquiryType INNER JOIN Patient.dbo.Patient (NOLOCK) AS P ON P.ACNPatID = CLH.MPNPatID WHERE LogDate = CONVERT(VARCHAR(10),GETDATE(),101)"
# user = "SQLMON"
# password = "gJWXwpmBW6nC"
#
# # read table data into a spark dataframe
# jdbcDF = spark.read.format("jdbc") \
#     .option("url", f"jdbc:sqlserver://DBSWP0796CLS.dmzmgmt.uhc.com:1433;databaseName={database};") \
#     .option("query", selectquery) \
#     .option("user", user) \
#     .option("password", password) \
#     .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
#     .load()
#
# # show the dat
# jdbcDF.show()
# jdbcDF.write \
#     .format('csv') \
#     .options(delimiter='|') \
#     .save("C:\\Users\\stiwar54\\PycharmProjects\\First\\just3.csv")