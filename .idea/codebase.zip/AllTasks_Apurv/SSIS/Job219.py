import logging
import time
import findspark
findspark.init()
from pyspark.sql.types import *
import numpy as np
from pyspark.sql import session
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_timestamp, lit
import pyodbc
import urllib
import sqlalchemy
import pandas as pd
import Config as config
from datetime import datetime
loaddate = str(datetime.now())[:-4]
spark = SparkSession.builder.appName("ETL")\
        .config("spark.driver.extraClassPath","spark-mssql-connector_2.12_3.0-1.0.0-alpha")\
        .getOrCreate()
spark.conf.set("spark.sql.debug.maxToStringFields", 1000)
# Create and configure logger
logging.basicConfig(filename="Job219.log",
                    format='%(asctime)s %(message)s',
                    filemode='w')
# Creating an object
logger = logging.getLogger()

# Setting the threshold of logger to DEBUG
logger.setLevel(logging.INFO)
def execute_sql(db, query,record_list):
    try:
        connection = pyodbc.connect('driver={%s};server=%s;database=%s;uid=%s;pwd=%s' % (config.Dev['driver'],
                                                                                         config.Dev['db_server'], db,
                                                                                         config.Dev['user'],
                                                                                         config.Dev['passwd']))
        cursor = connection.cursor()
        print(query)
        if "insert" in query:
            if not record_list :
                cursor.execute(query)
                print("Executed the query")
                logger.info("Executed the query - %s", query)
            else :
                cursor.executemany(query,record_list)
                print("Executed the query")
                logger.info("Executed the query - %s", query)
            connection.commit()
        else:
            cursor.execute(query)
            print("Executed the query")
            logger.info("Executed the query - %s", query)
            return cursor
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)

def get_loadnum():
    empty_list=[]
    insert_Load = "insert into eligibility..t_eligloads values ('" + loaddate + "','SutterHealth.txt'," \
                                                                                "'SutterHealthLoad','723')"
    execute_sql("Eligibility", insert_Load, empty_list)
    exec_sp = "exec usp_ClearTable 'SutterHealthLoad'"
    execute_sql("Eligibility", exec_sp, empty_list)
    selectloadnum = "Select Top 1 LoadNum from T_EligLoads where TableName='SutterHealthLoad' Order By LoadNum desc"
    cursor = execute_sql("Eligibility", selectloadnum,empty_list)
    return str(cursor.fetchone()[0])

def write_into_database(dataframe, database, table_name,  mode):
    dataframe.write \
        .format("jdbc") \
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
        .option("url","jdbc:sqlserver://Dbsed4555:1433;databaseName=Eligibility") \
        .option("dbtable", table_name) \
        .option("user", config.Dev['user']) \
        .option("password", config.Dev['passwd']) \
        .mode(saveMode=mode) \
        .save()

def readfile():
    df = spark.read.format("Text").option("header", "true").load("Job219_SutterHealth.txt")
    df2 = df.select(
        lit(get_loadnum()).alias('LoadNum'),
        df.value.substr(1, 1).alias('TransType'),
        df.value.substr(2, 8).alias('GroupNum'),
        df.value.substr(10, 9).alias('SubscriberNbr'),
        df.value.substr(19, 2).alias('Relationship'),
        df.value.substr(21, 12).alias('First'),
        df.value.substr(33, 1).alias('MI'),
        df.value.substr(34, 18).alias('Last'),
        df.value.substr(52, 30).alias('Address1'),
        df.value.substr(82, 30).alias('Address2'),
        df.value.substr(112, 15).alias('City'),
        df.value.substr(127, 2).alias('State'),
        df.value.substr(129, 5).alias('Zip'),
        df.value.substr(134, 4).alias('Zip4'),
        df.value.substr(138, 0).cast(DateType()).alias('DOB'),
        df.value.substr(138, 1).alias('Sex'),
        df.value.substr(139, 0).cast(DateType()).alias('Eff_Date'),
        df.value.substr(139, 0).cast(DateType()).alias('ExpDate'),
        df.value.substr(139, 15).alias('BenefitPlanID'),
        df.value.substr(154, 1).alias('MemberCOB'),
        df.value.substr(155, 3).alias('WrittenLang'),
        df.value.substr(158, 3).alias('SpokenLang'),
        df.value.substr(161, 19).alias('Filler')
    )
    print(type(df2))
    logger.info("Created the dataframe from the given data file")
    TableName = 'SutterHealthLoad'
    DatabaseName = "Eligibility"
    no_of_rows = df2.count()
    # Splitting the Dataframe if size is LARGE
    if(no_of_rows>=300000):
        samples = np.arange(10, 15, 0.5).tolist()
        dfArray = df2.randomSplit(samples, 24)
    else:
        dfArray = []
        dfArray.append(df2)
    params = 'DRIVER=' + config.Dev['driver'] + ';SERVER=' + config.Dev['db_server']  + ';PORT=1433;DATABASE=' + DatabaseName + ';UID=' + config.Dev['user'] + ';PWD=' + config.Dev['passwd']
    db_params = urllib.parse.quote_plus(params)
    engine = sqlalchemy.create_engine("mssql+pyodbc:///?odbc_connect={}".format(db_params))
    # df is the dataframe; test is table name in which this dataframe is #inserted
    start = time.time()
    logger.info("Started Writing to database")
    logger.info("Inserting into table %s", TableName)
    for dataf in dfArray:
        dataf = dataf.toPandas()
        dataf.to_sql(TableName, engine, index=False, if_exists="append", schema="dbo")
        print("Inserted",dataf.shape[0],"rows.")
    end = time.time()
    hours, rem = divmod(end - start, 3600)
    minutes, seconds = divmod(rem, 60)
    logger.info("Written to database Successfully")
    logger.info("Rows Inserted: {}".format(no_of_rows))
    logger.info("Time taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    print("\nTime taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))

def main():
    try:
        readfile()
        return 0
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)

if __name__ == "__main__":
    main()