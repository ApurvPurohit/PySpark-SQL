import logging
import time
import findspark
findspark.init()
from pyspark.sql.types import *
import numpy as np
from pyspark.sql import session
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_timestamp, lit
import pyodbc
import urllib
import sqlalchemy
import pandas as pd
import Config as config
from datetime import datetime
loaddate = str(datetime.now())[:-4]
spark = SparkSession.builder.appName("ETL")\
        .config("spark.driver.extraClassPath","sqljdbc42.jar")\
        .getOrCreate()
spark.conf.set("spark.sql.debug.maxToStringFields", 1000)
# Create and configure logger
logging.basicConfig(filename="Job212-Y9P.log",
                    format='%(asctime)s %(message)s',
                    filemode='w')
# Creating an object
logger = logging.getLogger()

# Setting the threshold of logger to DEBUG
logger.setLevel(logging.INFO)
def execute_sql(db, query):
    try:
        connection = pyodbc.connect('driver={%s};server=%s;database=%s;uid=%s;pwd=%s' % (config.Dev['driver'],
                                                                                         config.Dev['db_server'], db,
                                                                                         config.Dev['user'],
                                                                                         config.Dev['passwd']))
        cursor = connection.cursor()
        print(query)
        cursor.execute(query)
        print("Executed the query")
        logger.info("Executed the query - %s", query)
        if "insert" in query:
            connection.commit()
        else:
            return cursor
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)


def get_loadnum():
    empty_list=[]
    insert_Load = "insert into eligibility..t_eligloads values ('" + loaddate + "','F5748PGH.F5708X9P.ACNCNTLF.TXT'," \
                                                                                "'CDBMemberLoad','299')"
    execute_sql("Eligibility", insert_Load)
    exec_sp = "exec usp_ClearTable 'CDBMemberLoad'"
    execute_sql("Eligibility", exec_sp)
    selectloadnum = "Select Top 1 LoadNum from T_EligLoads where TableName='CDBMemberLoad' Order By LoadNum desc"
    cursor = execute_sql("Eligibility", selectloadnum)
    return str(cursor.fetchone()[0])

def write_into_database(dataframe, database, table_name,  mode):
    dataframe.write \
        .format("jdbc") \
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
        .option("url","jdbc:sqlserver://Dbsed4555:1433;databaseName=Eligibility") \
        .option("dbtable", table_name) \
        .option("user", config.Dev['user']) \
        .option("password", config.Dev['passwd']) \
        .mode(saveMode=mode) \
        .save()

def readfile():
    df = spark.read.format("Text").option("header", "true").load("F5748PGH.F5708Y9P.ACNELIGF_20210605.TXT")
    df2 = df.select(
        lit(get_loadnum()).alias('LoadNum'),
        df.value.substr(1, 1).alias('SourceInd'),
        df.value.substr(2, 1).alias('ActionInd'),
        df.value.substr(5, 4).alias('USSInd'),
        df.value.substr(9, 1).alias('TransRecordType'),
        df.value.substr(10, 7).alias('CustomerNumber'),
        df.value.substr(17, 11).alias('EmployeeID'),
        df.value.substr(28, 12).alias('FirstName'),
        df.value.substr(40, 1).alias('MI'),
        df.value.substr(41, 20).alias('LastName'),
        df.value.substr(61, 1).alias('Sex'),
        to_timestamp(df.value.substr(62, 0), 'yyyy-MM-dd HH:mm:ss').alias('DOB'),
        df.value.substr(70, 10).alias('HomePhone'),
        df.value.substr(80, 10).alias('WorkPhone'),
        df.value.substr(90, 2).alias('TICRelationship'),
        df.value.substr(92, 1).alias('CESRelationship'),
        df.value.substr(93, 2).alias('SequenceNum'),
        to_timestamp(df.value.substr(95, 0), 'yyyy-MM-dd HH:mm:ss').alias('EffDate'),
        to_timestamp(df.value.substr(103, 0), 'yyyy-MM-dd HH:mm:ss').alias('StopDate'),
        df.value.substr(111, 7).alias('PolicyNumber'),
        df.value.substr(118, 4).alias('PlanVarCoverage'),
        df.value.substr(122, 4).alias('ReportingCode'),
        df.value.substr(126, 1).alias('StatusInd'),
        df.value.substr(127, 2).alias('MemsCovered'),
        df.value.substr(129, 7).alias('MarketSite'),
        df.value.substr(136, 8).alias('ResMarketSite'),
        df.value.substr(144, 2).alias('ProductType'),
        df.value.substr(146, 1).alias('FeedbackBridgeInd'),
        df.value.substr(147, 1).alias('DependentDiffersInd'),
        df.value.substr(148, 8).alias('CommonUtility1'),
        df.value.substr(156, 1).alias('SurviveSpouseCode'),
        df.value.substr(157, 11).alias('PayeeSSN'),
        df.value.substr(168, 20).alias('PayeeLastName'),
        df.value.substr(188, 13).alias('PayeeFirstName'),
        df.value.substr(204, 1).alias('MaritalStatus'),
        df.value.substr(205, 32).alias('StreetAddress'),
        df.value.substr(237, 32).alias('CareOfAddress'),
        df.value.substr(269, 21).alias('City'),
        df.value.substr(290, 2).alias('State'),
        df.value.substr(292, 5).alias('Zip'),
        df.value.substr(297, 4).alias('ZipExt'),
        df.value.substr(301, 2).alias('Suffix'),
        df.value.substr(303, 6).alias('Account'),
        df.value.substr(311, 4).alias('Zone'),
        to_timestamp(df.value.substr(315, 0), 'yyyy-MM-dd HH:mm:ss').alias('UpdateTimeStamp'),
        df.value.substr(323, 11).alias('FormerEEID'),
        df.value.substr(342, 1).alias('MedicareTypeInd'),
        df.value.substr(343, 2).alias('CovType'),
        df.value.substr(345, 2).alias('PlanCode'),
        df.value.substr(347, 10).alias('BenefitSet'),
        df.value.substr(357, 11).alias('AltID'),
        df.value.substr(368, 64).alias('AltIDInd'),
        df.value.substr(432, 9).alias('PriorMemberID'),
        df.value.substr(441, 0).alias('MigratedtoTOPS')
    )
    logger.info("Created the dataframe from the given data file")
    print(type(df2),": Insertion begins")
    TableName = 'dbo.CDBMemberLoad'
    DatabaseName = "Eligibility"
    no_of_rows = df2.count()
    if(no_of_rows>=300000):
        samples = np.arange(10, 250, 0.5).tolist()
        dfArray = df2.randomSplit(samples, 24)
    else:
        dfArray = []
        dfArray.append(df2)    
    start = time.time()
    logger.info("Started Writing to database")
    logger.info("Inserting into table %s", TableName)
    for dataf in dfArray:
        print(dataf)
        write_into_database(dataf, 'Eligibility', TableName, 'Append')
        print("Rows Inserted:", dataf.count())
    end = time.time()
    hours, rem = divmod(end - start, 3600)
    minutes, seconds = divmod(rem, 60)
    logger.info("Written to database Successfully")
    logger.info("Rows Inserted: {}".format(df2.count()))
    logger.info("Time taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    print("\nTime taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))

def main():
    try:
        readfile()
        return 0
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)

if __name__ == "__main__":
    main()