import logging
import time
import findspark
findspark.init()
from pyspark.sql.types import *
import numpy as np
from pyspark.sql import session
from pyspark.sql import SparkSession
from pyspark.sql.functions import to_timestamp, lit
import pyodbc
import urllib
import sqlalchemy
import pandas as pd
import Config as config
from datetime import datetime
loaddate = str(datetime.now())[:-4]
spark = SparkSession.builder.appName("ETL")\
        .config("spark.driver.extraClassPath","sqljdbc42.jar")\
        .getOrCreate()
spark.conf.set("spark.sql.debug.maxToStringFields", 1000)
# Create and configure logger
logging.basicConfig(filename="Job212-X9P.log",
                    format='%(asctime)s %(message)s',
                    filemode='w')
# Creating an object
logger = logging.getLogger()

# Setting the threshold of logger to DEBUG
logger.setLevel(logging.INFO)
def execute_sql(db, query,record_list):
    try:
        connection = pyodbc.connect('driver={%s};server=%s;database=%s;uid=%s;pwd=%s' % (config.Dev['driver'],
                                                                                         config.Dev['db_server'], db,
                                                                                         config.Dev['user'],
                                                                                         config.Dev['passwd']))
        cursor = connection.cursor()
        print(query)
        if "insert" in query:
            if not record_list :
                cursor.execute(query)
                print("Executed the query")
                logger.info("Executed the query - %s", query)
            else :
                cursor.executemany(query,record_list)
                print("Executed the query")
                logger.info("Executed the query - %s", query)
            connection.commit()
        else:
            cursor.execute(query)
            print("Executed the query")
            logger.info("Executed the query - %s", query)
            return cursor
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)

def get_loadnum():
    empty_list=[]
    insert_Load = "insert into eligibility..t_eligloads values ('" + loaddate + "','F5748PGH.F5708X9P.ACNCNTLF.TXT'," \
                                                                                "'CDBGroupLoad','299')"
    execute_sql("Eligibility", insert_Load, empty_list)
    exec_sp = "exec usp_ClearTable 'CDBGroupLoad'"
    execute_sql("Eligibility", exec_sp, empty_list)
    selectloadnum = "Select Top 1 LoadNum from T_EligLoads where TableName='CDBGroupLoad' Order By LoadNum desc"
    cursor = execute_sql("Eligibility", selectloadnum,empty_list)
    return str(cursor.fetchone()[0])

def write_into_database(dataframe, database, table_name,  mode):
    dataframe.write \
        .format("jdbc") \
        .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver") \
        .option("url","jdbc:sqlserver://Dbsed4555:1433;databaseName=Eligibility") \
        .option("dbtable", table_name) \
        .option("user", config.Dev['user']) \
        .option("password", config.Dev['passwd']) \
        .mode(saveMode=mode) \
        .save()


def readfile():
    df = spark.read.format("Text").option("header", "true").load("F5748PGH.F5708X9P.ACNCNTLF_20210605.TXT")
    df2 = df.select(
        lit(get_loadnum()).alias('LoadNum'),
        df.value.substr(1, 1).alias('RecordType'),
        df.value.substr(2, 1).alias('ActionInd'),
        df.value.substr(3, 7).alias('CustomerNumber'),
        df.value.substr(10, 7).alias('GroupNum'),
        df.value.substr(17, 4).alias('PlanVarCoverage'),
        df.value.substr(21, 4).alias('ReportCodeCov'),
        df.value.substr(25, 30).alias('GroupName'),
        df.value.substr(55, 32).alias('CustomerCareOfAddress'),
        df.value.substr(87, 32).alias('CustomerStreetAddress'),
        df.value.substr(119, 21).alias('CustomerCity'),
        df.value.substr(140, 2).alias('CustomerState'),
        df.value.substr(142, 11).alias('CustomerZipCode'),
        df.value.substr(153, 21).alias('AnalystName1'),
        df.value.substr(174, 15).alias('AnalystName2'),
        df.value.substr(189, 0).alias('DateModified'),
        df.value.substr(189, 7).alias('TimeModified'),
        df.value.substr(196, 4).alias('Zone'),
        df.value.substr(200, 2).alias('SharedArrangement'),
        df.value.substr(202, 0).alias('SAStartDate'),
        df.value.substr(202, 0).alias('SAStopDate'),
        df.value.substr(202, 2).alias('NumberOfCov'),
        df.value.substr(204, 0).alias('CovStartDate'),
        df.value.substr(204, 0).alias('CovStopDate'),
        df.value.substr(204, 10).alias('CovBenefitSet'),
        df.value.substr(214, 2).alias('CovProductType'),
        df.value.substr(216, 11).alias('ProductCode'),
        df.value.substr(227, 5).alias('LegalEntity'),
        df.value.substr(232, 2).alias('CovCode'),
        df.value.substr(234, 6).alias('CovAccountCode'),
        df.value.substr(240, 2).alias('CovSuffix'),
        df.value.substr(242, 1).alias('FinanceInd'),
        df.value.substr(243, 1).alias('CoverageFBI'),
        df.value.substr(244, 0).alias('VendorStartDate'),
        df.value.substr(244, 0).alias('VendorStopDate'),
        df.value.substr(244, 2).alias('VendorProductType'),
        df.value.substr(246, 11).alias('VendorProductCode'),
        df.value.substr(257, 1).alias('VendorCSDInd'),
        df.value.substr(258, 1).alias('VendorARInd'),
        df.value.substr(259, 1).alias('VendorCustomerInd'),
        df.value.substr(260, 8).alias('VendorBulkMailLoc'),
        df.value.substr(268, 2).alias('VendorCallBenefit'),
        df.value.substr(270, 4).alias('VendorOptionCode1'),
        df.value.substr(274, 4).alias('VendorOptionCode2'),
        df.value.substr(278, 4).alias('VendorOptionCode3'),
        df.value.substr(282, 4).alias('VendorOptionCode4'),
        df.value.substr(286, 4).alias('VendorOptionCode5'),
        df.value.substr(290, 4).alias('VendorOptionCode6'),
        df.value.substr(294, 4).alias('VendorOptionCode7'),
        df.value.substr(298, 4).alias('VendorOptionCode8'),
        df.value.substr(302, 4).alias('VendorOptionCode9'),
        df.value.substr(306, 4).alias('VendorOptionCode10'),
        df.value.substr(310, 4).alias('VendorOptionCode11'),
        df.value.substr(314, 4).alias('VendorOptionCode12'),
        df.value.substr(318, 4).alias('VendorOptionCode13'),
        df.value.substr(322, 4).alias('VendorOptionCode14'),
        df.value.substr(326, 4).alias('VendorOptionCode15'),
        df.value.substr(330, 4).alias('VendorOptionCode16'),
        df.value.substr(334, 4).alias('VendorOptionCode17'),
        df.value.substr(338, 4).alias('VendorOptionCode18'),
        df.value.substr(342, 4).alias('VendorOptionCode19'),
        df.value.substr(346, 4).alias('VendorOptionCode20'),
        df.value.substr(350, 4).alias('VendorOptionCode21'),
        df.value.substr(354, 4).alias('VendorOptionCode22'),
        df.value.substr(358, 2).alias('ObligorID'),
        df.value.substr(360, 3).alias('MarketType'),
        df.value.substr(363, 3).alias('MigrationSourceCode')
    )
    logger.info("Created the dataframe from the given data file")
    print(type(df2))
    TableName = 'dbo.CDBGroupLoad'
    DatabaseName = "Eligibility"
    no_of_rows = df2.count()
    if (no_of_rows >= 300000):
        samples = np.arange(10, 30, 0.5).tolist()
        dfArray = df2.randomSplit(samples, 24)
    else:
        dfArray = []
        dfArray.append(df2)
    start = time.time()
    logger.info("Started Writing to database")
    logger.info("Inserting into table %s", TableName)
    for dataf in dfArray:
        write_into_database(dataf, 'Eligibility', TableName, 'Append')
        print("Rows Inserted:", dataf.count())
    end = time.time()
    hours, rem = divmod(end - start, 3600)
    minutes, seconds = divmod(rem, 60)
    logger.info("Written to database Successfully")
    logger.info("Rows Inserted: {}".format(df2.count()))
    logger.info("Time taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))
    print("\nTime taken: {:0>2}:{:0>2}:{:05.2f}".format(int(hours), int(minutes), seconds))

def main():
    try:
        readfile()
        return 0
    except Exception as e:
        print('Exception Occurred:', e.__class__.__name__)

if __name__ == "__main__":
    main()