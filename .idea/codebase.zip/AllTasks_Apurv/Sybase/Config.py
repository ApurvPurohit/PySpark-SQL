
Dev = {
    "db_server": "wn000022700",
    "user": "powerfacets",
    "passwd": "P#(8t?aSd:9r#`",
	"driver": "SQL Server",
    "port": "1433"
}

Sybase = {
    "db_server": "DBSPS0181",
    "user": "urn2dbo",
    "passwd": "ASDF0987kl@",
	"driver": "Adaptive Server Enterprise",
    "port": "4106"
}
#
# Stage = {
#     "db_server": "dbsws0517.dmzmgmt.uhc.com",
#     "user": "appPhysicalHealth",
#     "passwd": "6CzZJL7Ft95W",
# 	"driver": "SQL Server"
# }
#
# Prod = {
#     "db_server": "localhost",
#     "user": "",
#     "passwd": "my secret password",
# 	"driver": "SQL Server"
# }